/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "tempomap.h"

#include <regex.h>
#include <fstream>
#include <sstream>

using namespace std;


class TempoMap::Regex
{
    public:
    Regex(const std::string &regex, int flags) {
        regcomp(&_re, regex.c_str(), flags);
    }
    ~Regex() {
        regfree(&_re);
    }
    bool match(const std::string &str, int nmatch, regmatch_t pmatch[], int flags) const {
        return (regexec(&_re, str.c_str(), nmatch, pmatch, flags) == 0);
    }
    protected:
    regex_t _re;
};


static bool is_specified(const string &s, const regmatch_t &m)
{
    return ((m.rm_eo - m.rm_so) != 0);
}

static string extract_string(const string &s, const regmatch_t &m)
{
    uint len = m.rm_eo - m.rm_so;
    return len ? string(s.c_str() + m.rm_so, len) : "";
}

static uint extract_int(const string &s, const regmatch_t &m)
{
    uint len = m.rm_eo - m.rm_so;
    return len ? atoi(string(s.c_str() + m.rm_so, len).c_str()) : 0;
}


static const TempoMap::Regex regex_blank(
    "^[[:blank:]]*(#.*)?$",
    REG_EXTENDED | REG_NOSUB
);

static const TempoMap::Regex regex_valid(
    // label
    "^[[:blank:]]*(([[:alnum:]_-]+):)?" \
    // bars
    "[[:blank:]]*([[:digit:]]+)" \
    // tempo
    "[[:blank:]]+([[:digit:]]+)(-([[:digit:]]+))?" \
    // meter
    "([[:blank:]]+([[:digit:]]+)/([[:digit:]]+))?" \
    // accents
    "([[:blank:]]+([Xx.]+))?" \
    // volume
    "([[:blank:]]+([[:digit:]]+))?" \
    // comment
    "([[:blank:]]*#.*)?$",
    REG_EXTENDED
);
static const int RE_NMATCHES = 15,
                 IDX_LABEL = 2, IDX_BARS = 3, IDX_TEMPO = 4, IDX_TEMPO2 = 6,
                 IDX_BEATS = 8, IDX_DENOM = 9, IDX_ACCENTS = 11, IDX_VOLUME = 13;


static const TempoMap::Regex regex_single(
    // tempo
    "^[[:blank:]]*([[:digit:]]+)(-([[:digit:]]+)/([[:digit:]]+))?" \
    // meter
    "([[:blank:]]+([[:digit:]]+)/([[:digit:]]+))?" \
    // accents
    "([[:blank:]]+([Xx.]+))?[[:blank:]]*$",
    REG_EXTENDED
);
static const int RE_NMATCHES_SINGLE = 10,
                 IDX_TEMPO_SINGLE = 1, IDX_TEMPO2_SINGLE = 3, IDX_ACCEL_SINGLE = 4,
                 IDX_BEATS_SINGLE = 6, IDX_DENOM_SINGLE = 7, IDX_ACCENTS_SINGLE = 9;



std::vector<TempoMap::BeatType> TempoMap::parse_accents(const std::string &s, uint beats)
{
    vector<BeatType> accents;

    if (!s.empty())
    {
        if (s.length() == beats)
        {
            accents.resize(beats);
            for (uint n = 0; n < beats; n++) {
                accents[n] = (s[n] == 'X') ? BEAT_EMPHASIS :
                             (s[n] == 'x') ? BEAT_NORMAL : BEAT_SILENT;
            }
        }
        else
        {
            ostringstream os;
            os << "accent pattern length doesn't match number of beats";
            throw os.str();
        }
    }

    return accents;
}



TempoMapFile::TempoMapFile(const string & filename)
{
    ifstream file(filename.c_str());

    if (!file.is_open()) {
        ostringstream os;
        os << "can't open tempomap file: '" << filename << "'";
        throw os.str();
    }

    char line[256];
    int  lineno = 1;

    while (!file.eof())
    {
        file.getline(line, 256);

        if (!regex_blank.match(line, 0, NULL, 0))
        {
            regmatch_t match[RE_NMATCHES];

            if (regex_valid.match(line, RE_NMATCHES, match, 0))
            {
                Entry e;

                e.label = extract_string(line, match[IDX_LABEL]);
                e.bars    = extract_int(line, match[IDX_BARS]);
                e.tempo   = (float)extract_int(line, match[IDX_TEMPO]);
                e.tempo2  = (float)extract_int(line, match[IDX_TEMPO2]);   // 0 if empty
                e.beats   = is_specified(line, match[IDX_BEATS]) ? extract_int(line, match[IDX_BEATS]) : 4;
                e.denom   = is_specified(line, match[IDX_DENOM]) ? extract_int(line, match[IDX_DENOM]) : 4;
                e.accents = parse_accents(extract_string(line, match[IDX_ACCENTS]), e.beats);
                e.volume  = is_specified(line, match[IDX_VOLUME]) ? extract_int(line, match[IDX_VOLUME]) : 100;

                _entries.push_back(e);
            }
            else
            {
                ostringstream os;
                os << "invalid tempomap entry at line " << lineno << ":" << endl << line;
                throw os.str();
            }
        }

        lineno++;
    }
}



TempoMapSingle::TempoMapSingle(const string & line)
{
    regmatch_t match[RE_NMATCHES_SINGLE];

    if (regex_single.match(line, RE_NMATCHES_SINGLE, match, 0))
    {
        Entry e;

        e.label   = "";
        e.bars    = UINT_MAX;
        e.tempo   = (float)extract_int(line, match[IDX_TEMPO_SINGLE]);
        e.tempo2  = 0.0f;
        e.beats   = is_specified(line, match[IDX_BEATS_SINGLE]) ? extract_int(line, match[IDX_BEATS_SINGLE]) : 4;
        e.denom   = is_specified(line, match[IDX_DENOM_SINGLE]) ? extract_int(line, match[IDX_DENOM_SINGLE]) : 4;
        e.accents = parse_accents(extract_string(line, match[IDX_ACCENTS_SINGLE]), e.beats);
        e.volume  = 100;

        if (is_specified(line, match[IDX_TEMPO2_SINGLE]))
        {
            e.tempo2 = (float)extract_int(line, match[IDX_TEMPO2_SINGLE]);
            e.bars = extract_int(line, match[IDX_ACCEL_SINGLE]) * abs((int)e.tempo2 - (int)e.tempo);
            _entries.push_back(e);

            e.bars = UINT_MAX;
            e.tempo = e.tempo2;
            e.tempo2 = 0.0f;
            _entries.push_back(e);
        }
        else
        {
            _entries.push_back(e);
        }
    }
    else
    {
        ostringstream os;
        os << "invalid tempomap string:" << endl << line;
        throw os.str();
    }
}
