/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef _TEMPOMAP_H
#define _TEMPOMAP_H


class TempoMap
{
  public:
    enum BeatType {
        BEAT_EMPHASIS = 1,
        BEAT_NORMAL,
        BEAT_SILENT
    };

    struct Entry {
        std::string label;
        uint bars;
        float tempo;
        float tempo2;
        uint beats;
        uint denom;
        std::vector<BeatType> accents;
        uint volume;
    };

    class Regex;

    ~TempoMap() { }

    const Entry & operator[](uint n) const { return _entries[n]; }
    uint size() const { return _entries.size(); }

    const Entry * get_entry(const std::string & l) const
    {
        for (std::vector<Entry>::const_iterator i = _entries.begin(); i != _entries.end(); ++i) {
            if (i->label == l) return &*i;
        }
        return NULL;
    }

  protected:
    TempoMap() { };

    std::vector<BeatType> parse_accents(const std::string &s, uint);

    std::vector<Entry> _entries;
};


class TempoMapFile : public TempoMap
{
  public:
    TempoMapFile(const std::string & filename);
};


class TempoMapSingle : public TempoMap
{
  public:
    TempoMapSingle(const std::string & line);
};


#endif // _TEMPOMAP_H
