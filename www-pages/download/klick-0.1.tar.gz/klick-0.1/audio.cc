/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "audio.h"

#include <jack/jack.h>
#include <jack/transport.h>
#include <samplerate.h>
#include <sndfile.h>

#include <sstream>
#include <cmath>
#include <cerrno>

using namespace std;

AudioInterface::Accessor Audio;
AudioInterface * AudioInterface::single = NULL;


AudioInterface::AudioInterface(const string & name, const vector<string> & connect_ports, bool transport)
  : _process_obj(NULL), _enable_transport(transport)
{
    if ((_client = jack_client_new(name.c_str())) == 0) {
        throw "can't connect to jack server";
    }
    jack_set_process_callback(_client, &process_wrapper, (void*)this);

    if ((_output_port = jack_port_register(_client, "out", JACK_DEFAULT_AUDIO_TYPE, JackPortIsOutput, 0)) == NULL) {
        throw "can't register output port";
    }

    if (jack_activate(_client)) {
        throw "can't activate client";
    }

    for (vector<string>::const_iterator i = connect_ports.begin(); i != connect_ports.end(); i++) {
        int error = jack_connect(_client, jack_port_name(_output_port), i->c_str());
        if (error && error != EEXIST) {
            cerr << "can't connect '" << jack_port_name(_output_port) << "' to '" << i->c_str() << "'" << endl;
        }
    }

    _samplerate = jack_get_sample_rate(_client);

    single = this;
}


AudioInterface::~AudioInterface()
{
    single = NULL;

    jack_deactivate(_client);
    jack_client_close(_client);
}


bool AudioInterface::transport_rolling() const
{
    if (!_enable_transport) return false;
    return (jack_transport_query(_client, NULL) == JackTransportRolling);
}


jack_nframes_t AudioInterface::get_position() const
{
    if (!_enable_transport) return 0;

    jack_position_t pos;
    jack_transport_query(_client, &pos);
    return pos.frame;
}


int AudioInterface::process_wrapper(jack_nframes_t nframes, void *arg)
{
    AudioInterface *this_ = (AudioInterface*)arg;
    sample_t *buffer = (sample_t *)jack_port_get_buffer(this_->_output_port, nframes);

    memset(buffer, 0, nframes * sizeof(sample_t));

    if (this_->_process_obj) {
        (this_->_process_obj)->process(buffer, nframes);
    }

    return 0;
}



AudioData::AudioData(const sample_t *samples, jack_nframes_t length, jack_nframes_t samplerate, float volume)
  : _static_samples(samples), _samples(NULL), _length(length), _samplerate(samplerate)
{
    if (volume != 1.0f) {
        _samples = new sample_t[length];
        memcpy(_samples, samples, length * sizeof(sample_t));
        _static_samples = NULL;
        adjust_volume(volume);
    }
}


AudioData::AudioData(const string & filename, jack_nframes_t samplerate)
  : _static_samples(NULL)
{
    SF_INFO sfinfo = { 0 };
    SNDFILE* f;

    if ((f = sf_open(filename.c_str(), SFM_READ, &sfinfo)) == NULL) {
        ostringstream os;
        os << "failed to open audio file '" << filename << "'";
        throw os.str();
    }

    sample_t *buf = new sample_t[sfinfo.frames * sfinfo.channels];
    sf_readf_float(f, buf, sfinfo.frames);

    // convert stereo to mono
    sample_t *mono_buf;

    if (sfinfo.channels == 2) {
        mono_buf = new sample_t[sfinfo.frames];
        for (int i = 0; i < sfinfo.frames; i++) {
            mono_buf[i] = (buf[i*2] + buf[i*2 + 1]) / 2;
        }
        delete buf;
    }
    else {
        // in case there's more than 2 channels, use only the first
        mono_buf = buf;
    }

    // convert samplerate
    if (!(_samplerate = samplerate)) {
        _samplerate = Audio->get_samplerate();
    }
    resample(mono_buf, sfinfo.frames, sfinfo.samplerate, &_samples, _length, _samplerate);

    delete mono_buf;

    sf_close(f);
}


AudioData::AudioData(const AudioData & in, jack_nframes_t samplerate, float volume)
  : _static_samples(NULL)
{
    if (!(_samplerate = samplerate)) {
        _samplerate = Audio->get_samplerate();
    }
    if (in._samplerate != _samplerate) {
        resample(in.samples(), in.length(), in._samplerate, &_samples, _length, _samplerate);
    } else {
        _samples = new sample_t[in.length()];
        memcpy(_samples, in.samples(), in.length() * sizeof(sample_t));
        _length = in.length();
    }

    if (volume != 1.0f) {
        adjust_volume(volume);
    }
}


AudioData::~AudioData()
{
    if (_samples) {
        delete[] _samples;
    }
}


void AudioData::resample(const sample_t * samples_in, jack_nframes_t length_in, jack_nframes_t samplerate_in,
                         sample_t **samples_out, jack_nframes_t & length_out, jack_nframes_t samplerate_out)
{
    SRC_DATA src_data;
    int error;

    src_data.input_frames = length_in;
    src_data.data_in = const_cast<float*>(samples_in);

    src_data.src_ratio = (float)samplerate_out / (float)samplerate_in;

    src_data.output_frames = (long)ceil((float)length_in * src_data.src_ratio);
    src_data.data_out = new sample_t[src_data.output_frames];

    if ((error = src_simple(&src_data, SRC_SINC_BEST_QUALITY, 1)) != 0) {
        delete src_data.data_out;
        throw src_strerror(error);
    }

    *samples_out = src_data.data_out;
    length_out = src_data.output_frames;
}


void AudioData::adjust_volume(float volume)
{
    for (uint i = 0; i < _length; i++) {
        _samples[i] *= volume;
    }
}
