/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "metronome.h"
#include "audio.h"
#include "tempomap.h"

#include <cmath>
#include <algorithm>
#include <memory>
#include <sstream>

using namespace std;


Metronome::Metronome(const TempoMap & tempomap, float tempo_multiplier, int preroll, const string & start_label,
                    AudioDataPtr emphasis, AudioDataPtr normal)
  : _click_emphasis_data(emphasis), _click_normal_data(normal),
    _current(0), _pos(tempomap, tempo_multiplier, preroll, start_label),
    _running(true)
{
}


Metronome::~Metronome()
{
    Audio->set_process_obj(NULL);
}


void Metronome::start()
{
    Audio->set_process_obj(this);
}


void Metronome::process(sample_t *buffer, jack_nframes_t nframes)
{
    if (Audio->transport_enabled())
    {
        if (!Audio->transport_rolling())
            return;

        jack_nframes_t p = Audio->get_position();
        if (p != _prev + nframes) {
            // position changed since last period, need to relocate
            _current = p;
            _pos.locate(p);
            _play_click.reset();
        }
    }
    else
    {
        if (_pos.end_reached()) {
            _running = false;
            return;
        }
    }

    Click next_click = _pos.get_click();

    if (_current + nframes > next_click.frame)
    {
        // determine click type
        if (next_click.type == TempoMap::BEAT_EMPHASIS)
            _play_click = _click_emphasis_data;
        else if (next_click.type == TempoMap::BEAT_NORMAL)
            _play_click = _click_normal_data;
        _play_volume = next_click.volume;

        // _pos.advance() will usually be called only once, the loop is a safeguard to avoid segfaults
        // if two beats are less than period-size frames apart
        while (_pos.get_click().frame < _current + nframes && !_pos.end_reached()) {
            _pos.advance();
        }

        if (_play_click) {
            // start playing click
            jack_nframes_t offset = next_click.frame - _current;
            copy_audio(buffer + offset, _play_click->samples(), min(nframes - offset, _play_click->length()), _play_volume);
            _play_sample = nframes - offset;

            // finished already?
            if (_play_click->length() <= nframes - offset) {
                _play_click.reset();
            }
        }
    }
    else if (_play_click)
    {
        // continue previous click
        copy_audio(buffer, _play_click->samples() + _play_sample, min(nframes, _play_click->length() - _play_sample), _play_volume);
        _play_sample += nframes;

        // finished?
        if (_play_sample >= _play_click->length()) {
            _play_click.reset();
        }
    }

    _prev = _current;
    _current += nframes;
}


inline void Metronome::copy_audio(sample_t *dest, const sample_t *src, jack_nframes_t length, uint volume)
{
    if (volume == 100)
    {
        memcpy(dest, src, length * sizeof(sample_t));
    }
    else
    {
        float v = (float)volume / 100.0f;
        for (sample_t *end = dest + length; dest < end; dest++, src++) {
            *dest = *src * v;
        }
    }
}



Metronome::ClickPosition::ClickPosition(const TempoMap & tempomap, float multiplier, int preroll, const string & start_label)
  : _tempomap(tempomap), _multiplier(multiplier), _preroll_beats(0)
{
    // enable pre-roll and start-at-label only if jack transport is off
    if (!Audio->transport_enabled())
    {
        const TempoMap::Entry * e = _tempomap.get_entry(start_label);

        // number of pre-roll beats
        if (preroll == -1) {
            _preroll_beats = 2;
            _preroll_accents = 4; // no accents, so just make sure it's > 2
        }
        else if (preroll >= 1) {
            _preroll_beats = e ? e->beats * preroll : 0;
            _preroll_accents = e ? e->denom : 0;
        }

        // distance between two beats
        if (!e) e = &_tempomap[0];
        _preroll_dist = (float)Audio->get_samplerate() * (240.0f / e->denom) / e->tempo;

        reset();

        // move to start label
        if (!start_label.empty()) {
            if (!locate(start_label)) {
                locate(0); // label not found. should not happen
            }
        }
    }
}


void Metronome::ClickPosition::locate(jack_nframes_t frame)
{
    reset();

    if (frame == 0) return;

    while ((jack_nframes_t)_frame < frame && !_end) {
        advance();
    }
}


bool Metronome::ClickPosition::locate(const std::string & label)
{
    reset();

    while (_tempomap[_entry].label != label) {
        advance(true);
        if (_entry >= _tempomap.size()) {
            return false; // label not found
        }
    }
    _frame = 0.0f; // adjust position of start frame
    return true;
}


inline void Metronome::ClickPosition::advance(bool skip_preroll)
{
    if (!skip_preroll && _preroll_beats > 0) {
        _frame += _preroll_dist;
        _preroll_beats--;
        return;
    }

    if (_entry >= _tempomap.size()) {
        _end = true;
        return;
    }

    const TempoMap::Entry &e = _tempomap[_entry];
    float dist;

    if (e.tempo2 == 0.0f)  // constant tempo
    {
        dist = (float)Audio->get_samplerate() * (240.0f / e.denom) / e.tempo;
    }
    else    // gradual tempo change
    {
        // use doubles, otherwise the logarithms would lose some precision
        double tempo_start = e.tempo + (e.tempo2 - e.tempo) * ((double)(_bar * e.beats) + _beat    ) / (e.bars * e.beats);
        double tempo_end   = e.tempo + (e.tempo2 - e.tempo) * ((double)(_bar * e.beats) + _beat + 1) / (e.bars * e.beats);

        /*
                      / n-1 /              samplerate * 240 / denom               \     \
        dist =  lim   |  Σ  | --------------------------------------------------- | / n |
               n->inf \ x=0 \  tempo_start + (x / n) * (tempo_end - tempo_start)  /     /
        */

        // thanks to Derive, this becomes as simple as:
        dist = (float)Audio->get_samplerate() * (240.0f / e.denom) *
                    ((log(tempo_start) / (tempo_start - tempo_end)) + (log(tempo_end) / (tempo_end - tempo_start)));
    }

    _frame += dist / _multiplier;

    if (++_beat >= e.beats) {
        _beat = 0;
        if (++_bar >= e.bars) {
            _bar = 0;
            _entry++;
        }
    }
}


inline const Metronome::Click Metronome::ClickPosition::get_click() const
{
    TempoMap::BeatType t;

    // still in pre-roll
    if (_preroll_beats > 0) {
        if (_preroll_beats % _preroll_accents == 0) t = TempoMap::BEAT_EMPHASIS;
                                               else t = TempoMap::BEAT_NORMAL;
        return (Click) { (jack_nframes_t)_frame, t, 66 };
    }

    // end of tempomap, return "nothing"
    if (_entry >= _tempomap.size()) {
        return (Click) { (jack_nframes_t)_frame, TempoMap::BEAT_SILENT, 0 };
    }

    const TempoMap::Entry &e = _tempomap[_entry];

    if (e.accents.empty())
        t = (_beat == 0) ? TempoMap::BEAT_EMPHASIS : TempoMap::BEAT_NORMAL;
    else
        t = e.accents[_beat];

    return (Click){ (jack_nframes_t)_frame, t, e.volume };
}
