/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "klick.h"
#include "audio.h"
#include "tempomap.h"
#include "metronome.h"
#include "click_data.h"

#include <sstream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>

using namespace std;


Klick::Klick(int argc, char *argv[])
  : _quit(false)
{
    parse_options(argc, argv);

    if (_options.filename.empty() && _options.settings.empty())
    {
        throw "no tempo specified";
    }
    else
    {
        // load tempomap
        if (!_options.filename.empty()) {
            _map.reset(new TempoMapFile(_options.filename));
        } else {
            _map.reset(new TempoMapSingle(_options.settings));
        }
    }

    // make sure the start label exists
    bool found = false;
    for (uint i = 0; i < _map->size(); i++) {
        if ((*_map)[i].label == _options.start_label) found = true;
    }
    if (!found) {
        ostringstream os;
        os << "label '" << _options.start_label << "' not found in tempomap";
        throw os.str();
    }

    // determine client name (if not specified)
    if (_options.client_name.empty()) {
        ostringstream os;
        os << "klick-" << getpid();
        _options.client_name = os.str();
    }

    // setup jack
    _audio.reset(new AudioInterface(_options.client_name, _options.connect_ports, _options.enable_transport));

    // load audio samples
    AudioData *p_emphasis = NULL, *p_normal = NULL;

    switch (_options.click_sample) {
      case 0:
        p_emphasis = new AudioData(_options.click_filename_emphasis);
        p_normal   = new AudioData(_options.click_filename_normal);
        break;
      case 1:
        p_emphasis = new AudioData(CLICK_1_EMPHASIS_DATA);
        p_normal   = new AudioData(CLICK_1_NORMAL_DATA);
        break;
      case 2:
        p_emphasis = new AudioData(CLICK_2_EMPHASIS_DATA);
        p_normal   = new AudioData(CLICK_2_NORMAL_DATA);
        break;
    }

    if (_options.volume != 100) {
        p_emphasis->adjust_volume((float)_options.volume / 100.0f);
        p_normal->adjust_volume((float)_options.volume / 100.0f);
    }

    AudioDataPtr click_emphasis(p_emphasis);
    AudioDataPtr click_normal(p_normal);

    // create metronome object
    _metro.reset(new Metronome(*_map, (float)_options.tempo_percent / 100.0f,
                        _options.preroll, _options.start_label, click_emphasis, click_normal));
}


Klick::~Klick()
{
}


void Klick::print_version(ostream & out)
{
    out << "klick " STRINGIFY(VERSION) << endl << endl;
}


void Klick::print_usage(ostream & out)
{
    out << "Usage:" << endl
        << "  klick [ options ] tempo[-tempo2/accel] [meter] [pattern]" << endl
        << "  klick [ options ] -f tempomap-file" << endl
        << endl
        << "Options:" << endl
        <<  "  -n <name>            jack client name" << endl
        <<  "  -p <port,..>         jack port(s) to connect to" << endl
        <<  "  -s <number>          use built-in click sample 1 (default) or 2" << endl
        <<  "  -S <emphasis,normal> use the given files as click samples" << endl
        <<  "  -v <percent>         adjust playback volume" << endl
        <<  "  -t                   enable jack transport" << endl
        <<  "  -d <seconds>         delay before starting playback" << endl
        <<  "  -c <bars>            pre-roll. use -c 0 for 2 beats" << endl
        <<  "  -l <label>           start playback at the given label" << endl
        <<  "  -x <percent>         multiply tempo by the given factor" << endl
        <<  "  -h                   show this help" << endl
        << endl
        << "Tempomap file format:" << endl
        << "  [label:] bars tempo[-tempo2] [meter] [pattern] [volume]" << endl
        << "  ..." << endl;
}


void Klick::parse_options(int argc, char *argv[])
{
    int c;
    char optstring[] = "-f:n:p:s:S:v:td:c:l:x:h";
    char *end;

    while ((c = getopt(argc, argv, optstring)) != -1)
    {
        switch (c)
        {
            case 1:
                if (!_options.settings.empty()) _options.settings += " ";
                _options.settings += string(::optarg);
                break;
            case 'f':
                _options.filename = string(::optarg);
                break;
            case 'n':
                _options.client_name = string(::optarg);
                break;
            case 'p':
              { char *p = strtok(::optarg, ",");  // yuck
                while (p) {
                    _options.connect_ports.push_back(string(p));
                    p = strtok(NULL, ",");
                }
              } break;
            case 's':
                _options.click_sample = strtoul(::optarg, &end, 10);
                if (*end != '\0' || _options.click_sample < 1 || _options.click_sample > 2) {
                    throw "invalid click sample number";
                }
                break;
            case 'S':
              { string s(::optarg);
                string::size_type comma = s.find(',');
                if (comma != string::npos && comma == s.rfind(',')) {
                    _options.click_filename_emphasis = string(s, 0, comma);
                    _options.click_filename_normal = string(s, comma + 1, s.length() - comma);
                } else {
                    throw "invalid click sample file names";
                }
                _options.click_sample = 0;
              } break;
            case 'v':
                _options.volume = strtoul(::optarg, &end, 10);
                if (*end != '\0') throw "invalid volume";
                break;
            case 't':
                _options.enable_transport = true;
                break;
            case 'd':
                _options.delay = strtod(::optarg, &end);
                if (*end != '\0' || _options.delay < 0.0f) throw "invalid delay";
                break;
            case 'c':
                _options.preroll = strtoul(::optarg, &end, 10);
                if (*end != '\0') throw "invalid pre-roll";
                if (_options.preroll == 0) _options.preroll = -1;
                break;
            case 'l':
                _options.start_label = string(::optarg);
                break;
            case 'x':
                _options.tempo_percent = strtoul(::optarg, &end, 10);
                if (*end != '\0') throw "invalid tempo multiplier";
                break;
            case 'h':
                print_version(cout);
                print_usage(cout);
                exit(EXIT_SUCCESS);
                break;
            default:
                print_usage(cerr);
                exit(EXIT_FAILURE);
                break;
        }
    }
}


void Klick::run()
{
    if (!_options.enable_transport) {
        usleep((unsigned long)(_options.delay * 1000000));
    }
    _metro->start();

    while (!_quit && _metro->running()) {
        usleep(100000);
    };
}


void Klick::signal_quit()
{
    _quit = true;
}
