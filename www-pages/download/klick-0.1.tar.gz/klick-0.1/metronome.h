/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef _METRONOME_H
#define _METRONOME_H

#include "audio.h"
#include "tempomap.h"


class Metronome : protected AudioCallback
{
  public:
    Metronome(const TempoMap &, float tempo_multiplier, int preroll, const std::string & start_label,
              AudioDataPtr emphasis, AudioDataPtr normal);
    ~Metronome();

    void start();
    bool running() const { return _running; }

  protected:
    struct Click
    {
        jack_nframes_t frame;
        TempoMap::BeatType type;
        uint volume;
    };

    class ClickPosition
    {
      public:
        ClickPosition(const TempoMap &, float multiplier, int preroll, const std::string & start_label);

        void locate(jack_nframes_t);
        bool locate(const std::string & label);
        inline void advance(bool skip_preroll = false);

        inline const Click get_click() const;
        bool end_reached() const { return _end; }

      private:
        void reset() {
            _frame = 0.0f;
            _entry = _bar = _beat = 0;
            _end = false;
        }

        double _frame;
        uint _entry, _bar, _beat;
        bool _end;

        const TempoMap & _tempomap;
        float _multiplier;

        uint _preroll_beats;
        uint _preroll_accents;
        float _preroll_dist;
    };

    virtual void process(sample_t *, jack_nframes_t);
    inline void copy_audio(sample_t *dest, const sample_t *src, jack_nframes_t length, uint volume);

    AudioDataPtr _click_emphasis_data;
    AudioDataPtr _click_normal_data;

    AudioDataPtr _play_click;
    uint _play_volume;
    jack_nframes_t _play_sample;

    jack_nframes_t _current;
    jack_nframes_t _prev;

    ClickPosition _pos;

    volatile bool _running;
};

#endif // _METRONOME_H
