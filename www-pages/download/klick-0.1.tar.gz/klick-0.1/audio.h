/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef _AUDIO_H
#define _AUDIO_H

#include <jack/types.h>

typedef jack_default_audio_sample_t sample_t;


class AudioCallback
{
  protected:
    AudioCallback() { }
    virtual ~AudioCallback() { }
    friend class AudioInterface;
    virtual void process(sample_t *, jack_nframes_t) = 0;
};


class AudioInterface
{
  public:
    AudioInterface(const std::string & name, const std::vector<std::string> & connect_ports, bool transport);
    ~AudioInterface();

    void set_process_obj(AudioCallback * obj) { _process_obj = obj; }
    jack_nframes_t get_samplerate() const { return _samplerate; }
    bool transport_enabled() const { return _enable_transport; }
    bool transport_rolling() const;
    jack_nframes_t get_position() const;

    struct Accessor {
        inline AudioInterface * operator->() { return single; }
    };

  protected:
    static int process_wrapper(jack_nframes_t, void *);

    AudioCallback *_process_obj;

    jack_client_t *_client;
    jack_port_t   *_output_port;
    jack_nframes_t _samplerate;

    bool _enable_transport;

  private:
    static AudioInterface * single;
};


extern AudioInterface::Accessor Audio;



class AudioData
{
  public:
    AudioData(const sample_t *samples, jack_nframes_t length, jack_nframes_t samplerate, float volume = 1.0f);
    AudioData(const std::string & filename, jack_nframes_t samplerate = 0);
    AudioData(const AudioData & in, jack_nframes_t samplerate = 0, float volume = 1.0f);
    ~AudioData();

    const sample_t *samples() const { return _samples ? : _static_samples; }
    jack_nframes_t length() const { return _length; }

    void adjust_volume(float);

  protected:
    void resample(const sample_t *, jack_nframes_t, jack_nframes_t,
                  sample_t **, jack_nframes_t &, jack_nframes_t);

    const sample_t *_static_samples;
    sample_t *_samples;
    jack_nframes_t _length;
    jack_nframes_t _samplerate;
};


typedef boost::shared_ptr<AudioData> AudioDataPtr;


#endif // _AUDIO_H
