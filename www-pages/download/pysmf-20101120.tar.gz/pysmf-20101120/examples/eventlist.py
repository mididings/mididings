import smf
import sys

filename = sys.argv[1]
tracknum = int(sys.argv[2])

print "opening file '%s'..." % filename
f = smf.SMF(filename)

t = f.tracks[tracknum]

print "---"
print "listing binary data for track %d:" % tracknum
print "---"
for e in t.events:
    print e.midi_buffer

print "---"
print "listing decoded events for track %d:" % tracknum
print "---"
for e in t.events:
    print e.decode()
