/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "tempomap.h"

#include <fstream>
#include <sstream>

using namespace std;


// matches a line that contains nothing but whitespace or comments
static const TempoMap::Regex regex_blank(
    "^[[:blank:]]*(#.*)?$",
    REG_EXTENDED | REG_NOSUB
);

// matches any valid line in a tempomap file
static const TempoMap::Regex regex_valid(
    // label
    "^[[:blank:]]*(([[:alnum:]_-]+):)?" \
    // bars
    "[[:blank:]]*([[:digit:]]+)" \
    // meter
    "([[:blank:]]+([[:digit:]]+)/([[:digit:]]+))?" \
    // tempo
    "[[:blank:]]+([[:digit:]]+)(-([[:digit:]]+))?" \
    // accents
    "([[:blank:]]+([Xx.]+))?" \
    // volume
    "([[:blank:]]+([[:digit:]]+))?" \
    // comment
    "[[:blank:]]*(#.*)?$",
    REG_EXTENDED
);
static const int RE_NMATCHES = 15,
                 IDX_LABEL = 2, IDX_BARS = 3, IDX_BEATS = 5, IDX_DENOM = 6,
                 IDX_TEMPO = 7, IDX_TEMPO2 = 9, IDX_ACCENTS = 11, IDX_VOLUME = 13;


// matches valid tempo parameters on the command line
static const TempoMap::Regex regex_single(
    // meter
    "^[[:blank:]]*(([[:digit:]]+)/([[:digit:]]+)[[:blank:]]+)?" \
    // tempo
    "([[:digit:]]+)(-([[:digit:]]+)/([[:digit:]]+))?" \
    // accents
    "([[:blank:]]+([Xx.]+))?[[:blank:]]*$",
    REG_EXTENDED
);
static const int RE_NMATCHES_SINGLE = 10,
                 IDX_BEATS_SINGLE = 2, IDX_DENOM_SINGLE = 3, IDX_TEMPO_SINGLE = 4,
                 IDX_TEMPO2_SINGLE = 6, IDX_ACCEL_SINGLE = 7, IDX_ACCENTS_SINGLE = 9;


std::vector<TempoMap::BeatType> TempoMap::parse_accents(const std::string &s, uint nbeats)
{
    vector<BeatType> accents;

    if (!s.empty()) {
        if (s.length() == nbeats) {
            accents.resize(nbeats);
            for (uint n = 0; n < nbeats; n++) {
                accents[n] = (s[n] == 'X') ? BEAT_EMPHASIS :
                             (s[n] == 'x') ? BEAT_NORMAL : BEAT_SILENT;
            }
        } else {
            ostringstream os;
            os << "accent pattern length doesn't match number of beats";
            throw os.str();
        }
    }
    return accents;
}

/*
 * loads tempomap from a file
 */
TempoMapFile::TempoMapFile(const string & filename)
{
    ifstream file(filename.c_str());

    if (!file.is_open()) {
        ostringstream os;
        os << "can't open tempomap file: '" << filename << "'";
        throw os.str();
    }

    char line[256];
    int  lineno = 1;

    while (!file.eof())
    {
        file.getline(line, 256);

        if (!regex_blank.match(line, 0, NULL, 0)) {
            regmatch_t match[RE_NMATCHES];

            if (regex_valid.match(line, RE_NMATCHES, match, 0)) {
                Entry e;

                e.label = extract_string(line, match[IDX_LABEL]);
                e.bars    = extract_int(line, match[IDX_BARS]);
                e.tempo   = (float)extract_int(line, match[IDX_TEMPO]);
                e.tempo2  = (float)extract_int(line, match[IDX_TEMPO2]);   // 0 if empty
                e.beats   = is_specified(line, match[IDX_BEATS]) ? extract_int(line, match[IDX_BEATS]) : 4;
                e.denom   = is_specified(line, match[IDX_DENOM]) ? extract_int(line, match[IDX_DENOM]) : 4;
                e.accents = parse_accents(extract_string(line, match[IDX_ACCENTS]), e.beats);
                e.volume  = is_specified(line, match[IDX_VOLUME]) ? extract_int(line, match[IDX_VOLUME]) : 100;

                _entries.push_back(e);
            } else {
                ostringstream os;
                os << "invalid tempomap entry at line " << lineno << ":" << endl << line;
                throw os.str();
            }
        }
        lineno++;
    }
}

/*
 * loads single-line tempomap from a string
 */
TempoMapSingle::TempoMapSingle(const string & line)
{
    regmatch_t match[RE_NMATCHES_SINGLE];

    if (regex_single.match(line, RE_NMATCHES_SINGLE, match, 0))
    {
        Entry e;

        e.label   = "";
        e.bars    = UINT_MAX;
        e.beats   = is_specified(line, match[IDX_BEATS_SINGLE]) ? extract_int(line, match[IDX_BEATS_SINGLE]) : 4;
        e.denom   = is_specified(line, match[IDX_DENOM_SINGLE]) ? extract_int(line, match[IDX_DENOM_SINGLE]) : 4;
        e.tempo   = (float)extract_int(line, match[IDX_TEMPO_SINGLE]);
        e.tempo2  = 0.0f;
        e.accents = parse_accents(extract_string(line, match[IDX_ACCENTS_SINGLE]), e.beats);
        e.volume  = 100;

        if (is_specified(line, match[IDX_TEMPO2_SINGLE])) {
            // tempo change...
            e.tempo2 = (float)extract_int(line, match[IDX_TEMPO2_SINGLE]);
            e.bars = extract_int(line, match[IDX_ACCEL_SINGLE]) * abs((int)e.tempo2 - (int)e.tempo);
            _entries.push_back(e);

            // add a second entry, to be played once the "target" tempo is reached
            e.bars = UINT_MAX;
            e.tempo = e.tempo2;
            e.tempo2 = 0.0f;
            _entries.push_back(e);
        } else {
            // no tempo change, just add this single entry
            _entries.push_back(e);
        }
    }
    else
    {
        ostringstream os;
        os << "invalid tempomap string:" << endl << line;
        throw os.str();
    }
}
