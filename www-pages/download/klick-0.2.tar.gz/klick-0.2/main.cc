/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "main.h"
#include "klick.h"

#include <csignal>


static Klick *app = NULL;


static void main_signal_handler(int sig)
{
    app->signal_quit();
}


static void main_terminate(const char * e)
{
    std::cerr << "error: " << e << std::endl;
    delete app;
    exit(EXIT_FAILURE);
}


int main(int argc, char *argv[])
{
    try {
        app = new Klick(argc, argv);

        // exit cleanly when terminated
        signal(SIGINT,  main_signal_handler);
        signal(SIGTERM, main_signal_handler);
        signal(SIGQUIT, main_signal_handler);
        signal(SIGHUP,  main_signal_handler);

        app->run();
        delete app;

        return EXIT_SUCCESS;
    }
    catch (const char *e) {
        main_terminate(e);
    }
    catch (const std::string & e) {
        main_terminate(e.c_str());
    }
}
