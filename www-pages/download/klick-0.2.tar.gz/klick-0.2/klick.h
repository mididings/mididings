/*
 * klick
 *
 * Copyright (C) 2007  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef _KLICK_H
#define _KLICK_H

class AudioInterface;  // fwd
class TempoMap;
class Metronome;


class Klick
{
  public:
    struct Options
    {
        Options() : click_sample(1), volume(100), enable_transport(false),
                    delay(0.0f), preroll(0), tempo_percent(100) { }

        std::string client_name;
        std::string filename;
        std::string settings;
        std::vector<std::string> connect_ports;
        uint click_sample;
        std::string click_filename_emphasis;
        std::string click_filename_normal;
        uint volume;
        bool enable_transport;
        float delay;
        int preroll;
        std::string start_label;
        uint tempo_percent;
    };

    Klick(int argc, char *argv[]);
    ~Klick();

    void run();
    void signal_quit();

  protected:
    void print_version(std::ostream &);
    void print_usage(std::ostream &);

    void parse_options(int argc, char *argv[]);

    Options _options;
    boost::shared_ptr<TempoMap> _map;
    boost::shared_ptr<AudioInterface> _audio;
    boost::shared_ptr<Metronome> _metro;

    volatile bool _quit;
};


#endif // _KLICK_H
