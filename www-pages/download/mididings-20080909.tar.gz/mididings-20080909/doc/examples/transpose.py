#
# transpose.py - probably the most simple example that actually does something useful ;)
#

from mididings import *

# transpose all notes down one minor third (3 semitones)
run(Transpose(-3))
