#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup, Extension
from distutils.command.build_scripts import build_scripts
from distutils import util
import os, sys


if '--with-pyrex' in sys.argv:
    from Pyrex.Distutils import build_ext
    sys.argv.remove('--with-pyrex')
    with_pyrex = True
else:
    with_pyrex = False


class build_scripts_rename(build_scripts):
    def copy_scripts(self):
        build_scripts.copy_scripts(self)
        # remove the .py extension from scripts
        for s in self.scripts:
            f = util.convert_path(s)
            before = os.path.join(self.build_dir, os.path.basename(f))
            after = os.path.splitext(before)[0]
            print "renaming", before, "->", after
            os.rename(before, after)


cmdclass = {
    'build_scripts': build_scripts_rename
}

ext_modules = [
    Extension('liblo',
              [with_pyrex and 'src/liblo.pyx' or 'src/liblo.c'],
              extra_compile_args = ['-fno-strict-aliasing'],
              libraries = ['lo'])
]

if with_pyrex:
    cmdclass['build_ext'] = build_ext


setup (
    name = 'pyliblo',
    version = '0.6.4',
    author = 'Dominic Sacre',
    author_email = 'dominic.sacre@gmx.de',
    url = 'http://das.nasophon.de/pyliblo/',
    description = 'A Python wrapper for the liblo OSC library',
    license = "GPL",
    scripts = [
        'scripts/send_osc.py',
        'scripts/dump_osc.py',
    ],
    cmdclass = cmdclass,
    ext_modules = ext_modules
)
