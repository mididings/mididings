# -*- coding: utf-8 -*-
#
# mididings
#
# Copyright (C) 2008  Dominic Sacré  <dominic.sacre@gmx.de>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#

import _mididings

from .base import _Unit, _Filter


_conditions = { }
_counter = 0


def _get_cond_number(cond):
    try:
        return _conditions[cond]
    except:
        global _counter
        r = _counter
        _conditions[cond] = _counter
        _counter = _counter + 1
        return r


class If(_mididings.If, _Filter):
    def __init__(self, cond):
        _mididings.If.__init__(self, _get_cond_number(cond))


class Set(_mididings.Set, _Unit):
    def __init__(self, cond, value):
        _mididings.Set.__init__(self, _get_cond_number(cond), value)
