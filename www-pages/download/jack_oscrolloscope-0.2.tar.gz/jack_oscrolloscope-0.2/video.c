/*
 * jack_oscrolloscope
 *
 * Copyright (C) 2006  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <SDL.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "main.h"
#include "video.h"


static void video_exit();

void (*video_update)(int, int);
static void video_update_gl(int, int);
static void video_update_sdl(int, int);


int video_ticks_per_frame = 1000 / DEFAULT_FPS;
static int ticks = 0;

bool video_scrolling = true;

bool video_use_gl = false;
bool video_use_gl_fbo = false;
int  video_width = DEFAULT_WIDTH;
int  video_height = 0;


// for SDL drawing mode only
static SDL_Surface *screen = NULL;
static SDL_Surface *buffer_surface = NULL;

SDL_PixelFormat *video_pix_fmt = NULL;
SDL_Surface *video_draw_surface = NULL;
update_rect video_updates[2] = { { false } };

// OpenGL mode only
static GLuint framebuffer = 0;
static GLuint texture = 0;


PFNGLGENFRAMEBUFFERSEXTPROC         glGenFramebuffersEXT        = NULL;
PFNGLDELETEFRAMEBUFFERSEXTPROC      glDeleteFramebuffersEXT     = NULL;
PFNGLBINDFRAMEBUFFEREXTPROC         glBindFramebufferEXT        = NULL;
PFNGLFRAMEBUFFERTEXTURE2DEXTPROC    glFramebufferTexture2DEXT   = NULL;
PFNGLCHECKFRAMEBUFFERSTATUSEXTPROC  glCheckFramebufferStatusEXT = NULL;


void video_init()
{
    if (video_use_gl)
    {
        if (video_ticks_per_frame == 0) {
            // attempt to enable vsync, which makes scrolling more smooth.
            // this probably has no effect on anything but nVidia cards.
            setenv("__GL_SYNC_TO_VBLANK", "1", 0);
#if SDL_VERSION_ATLEAST(1, 2, 10)
            // this might help, too... but has no effect for me
            SDL_GL_SetAttribute(SDL_GL_SWAP_CONTROL, 1);
#endif
        }
        SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

        // may be overridden later via video_set_update_func()
        video_update = video_update_gl;
    }
    else
    {
        video_update = video_update_sdl;
    }

    video_set_mode(video_width, video_height);

    atexit(video_exit);
}


static void video_exit()
{
    if (video_use_gl)
    {
        if (video_use_gl_fbo) {
            glDeleteFramebuffersEXT(1, &framebuffer);
            glDeleteTextures(1, &texture);
        }
    }
    else
    {
        if (video_scrolling) SDL_FreeSurface(buffer_surface);
    }
}


void video_set_mode(int w, int h)
{
    if ((screen = SDL_SetVideoMode(w, h, VIDEO_BPP, (video_use_gl ? VIDEO_FLAGS_GL : VIDEO_FLAGS_SDL))) == NULL) {
        fprintf(stderr, "can't set video mode: %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }

    if (video_use_gl)
    {
        video_use_gl_fbo = true;
        if (!check_opengl_extension("GL_EXT_framebuffer_object")) {
            fprintf(stderr, "missing OpenGL framebuffer object extension\n");
            video_use_gl_fbo = false;
        }
        if (!check_opengl_extension("GL_ARB_texture_rectangle")) {
            fprintf(stderr, "missing OpenGL texture rectangle extension\n");
            video_use_gl_fbo = false;
        }

        if (video_use_gl_fbo)
        {
            glGenFramebuffersEXT        = SDL_GL_GetProcAddress("glGenFramebuffersEXT");
            glDeleteFramebuffersEXT     = SDL_GL_GetProcAddress("glDeleteFramebuffersEXT");
            glBindFramebufferEXT        = SDL_GL_GetProcAddress("glBindFramebufferEXT");
            glFramebufferTexture2DEXT   = SDL_GL_GetProcAddress("glFramebufferTexture2DEXT");
            glCheckFramebufferStatusEXT = SDL_GL_GetProcAddress("glCheckFramebufferStatusEXT");

            if (framebuffer) glDeleteFramebuffersEXT(1, &framebuffer);
            if (texture) glDeleteTextures(1, &texture);

            glGenFramebuffersEXT(1, &framebuffer);
            glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer);

            glGenTextures(1, &texture);
            glBindTexture(GL_TEXTURE_RECTANGLE_ARB, texture);

            glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0);
            glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_RECTANGLE_ARB, texture, 0);

            glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

            if (glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT) != GL_FRAMEBUFFER_COMPLETE_EXT) {
                fprintf(stderr, "failed setting up OpenGL framebuffer\n");
                // try without
                video_use_gl_fbo = false;
                glDeleteFramebuffersEXT(1, &framebuffer);
                glDeleteTextures(1, &texture);
            }

            glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        }

        glClear(GL_COLOR_BUFFER_BIT);

        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, w, h, 0, 0, 1);

        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glDisable(GL_BLEND);
    }
    else // SDL
    {
        video_pix_fmt = screen->format;

        if (video_scrolling) {
            if (buffer_surface) SDL_FreeSurface(buffer_surface);
            buffer_surface = SDL_CreateRGBSurface(SURFACE_FLAGS, w, h, video_pix_fmt->BitsPerPixel,
                                        video_pix_fmt->Rmask, video_pix_fmt->Gmask, video_pix_fmt->Bmask, video_pix_fmt->Amask);
        }
    }

    video_width = w;
    video_height = h;
}


void video_resize(int w, int h)
{
    video_set_mode(w, h);
}


void video_set_update_func(void (*update_func)(int, int))
{
    video_update = update_func;
}


void video_set_draw_target(video_draw_target t)
{
    if (video_use_gl && video_use_gl_fbo)
    {
        switch (t) {
            case DRAW_TO_SCREEN:
                glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
                break;
            case DRAW_TO_BUFFER:
                glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer);
                break;
        }
    }
    else if (!video_use_gl)
    {
        switch (t) {
            case DRAW_TO_SCREEN:
                video_draw_surface = screen;
                break;
            case DRAW_TO_BUFFER:
                video_draw_surface = video_scrolling ? buffer_surface : screen;
                break;
        }
    }
}


static void video_update_gl(int pos, int prev_pos)
{
    if (video_use_gl_fbo)
    {
        void inline draw_quad(int x, int y, int w, int h, int dx, int dy) {
            // texture is upside down!
            glTexCoord2f(x,     y + h); glVertex2i(dx,     dy    );
            glTexCoord2f(x + w, y + h); glVertex2i(dx + w, dy    );
            glTexCoord2f(x + w, y    ); glVertex2i(dx + w, dy + h);
            glTexCoord2f(x,     y    ); glVertex2i(dx,     dy + h);
        }

        glEnable(GL_TEXTURE_RECTANGLE_ARB);
        glBindTexture(GL_TEXTURE_RECTANGLE_ARB, texture);

        glColor3f(1.0f, 1.0f, 1.0f);

        glBegin(GL_QUADS);

        if (video_scrolling) {
            draw_quad(0, 0, pos, video_height, video_width - pos, 0);
            draw_quad(pos, 0, video_width - pos, video_height, 0, 0);
        } else {
            draw_quad(0, 0, video_width, video_height, 0, 0);
        }

        glEnd();

        glDisable(GL_TEXTURE_RECTANGLE_ARB);
        glBindTexture(GL_TEXTURE_RECTANGLE_ARB, 0);
    }
}


static void video_update_sdl(int pos, int prev_pos)
{
    if (video_scrolling)
    {
        /*          pos
        *  +--------+--------------------+
        *  | r_src1 |       r_src2       |  buffer_surface
        *  +--------+--------------------+
        *
        *  +--------------------+--------+
        *  |      r_dst2        | r_dst1 |  screen
        *  +--------------------+--------+
        */

        // left part of source surface first
        SDL_Rect r_src1 = { 0, 0, pos, video_height };
        SDL_Rect r_dst1 = { video_width - pos, 0, 0, 0 };
        SDL_BlitSurface(buffer_surface, &r_src1, screen, &r_dst1);
        // now the second part
        SDL_Rect r_src2 = { pos, 0, video_width - pos, video_height };
        SDL_Rect r_dst2 = { 0, 0, 0, 0 };
        SDL_BlitSurface(buffer_surface, &r_src2, screen, &r_dst2);

        // need to update whole window
        video_updates[0].rect.x = video_updates[0].rect.y = video_updates[0].rect.w = video_updates[0].rect.h = 0;
        video_updates[0].use = true;
    }
    else
    {
        // no need to blit, since we've already drawn directly to the screen surface

        // find out which portions of the screen to update
        if (pos >= prev_pos)
        {
            video_updates[0].rect.x = prev_pos;
            video_updates[0].rect.w = min(pos + 4 - prev_pos, video_width - prev_pos);
            if (pos > video_width - 2) {
                video_updates[1].rect.x = 0;
                video_updates[1].rect.w = 2;
                video_updates[1].use = true;
            }
        }
        else
        {
            video_updates[0].rect.x = 0;
            video_updates[0].rect.w = pos + 4;
            video_updates[0].use = true;
            video_updates[1].rect.x = prev_pos;
            video_updates[1].rect.w = video_width - prev_pos;
            video_updates[1].use = true;
        }
        video_updates[0].use = true;
        video_updates[0].rect.y = video_updates[1].rect.y = 0;
        video_updates[0].rect.h = video_updates[1].rect.h = video_height;
    }
}


void video_flip()
{
    while (SDL_GetTicks() < ticks + video_ticks_per_frame) {
        SDL_Delay(1);
    }
    ticks = SDL_GetTicks();

    if (video_use_gl)
    {
        SDL_GL_SwapBuffers();
    }
    else
    {
        for (int n = 0; n < 2; n++) {
            if (video_updates[n].use) {
                SDL_UpdateRect(screen, video_updates[n].rect.x, video_updates[n].rect.y,
                                       video_updates[n].rect.w, video_updates[n].rect.h);
                video_updates[n].use = false;
            }
        }
    }
}


bool check_opengl_extension(const char *ext)
{
    static const char* extensions = NULL;

    const char* start;
    char*       where;
    char*       terminator;
    bool        supported;

    if (!extensions) {
        extensions = (const char*)glGetString(GL_EXTENSIONS);
        if (!extensions) return false;
    }

    start = extensions;
    supported = false;
    while (!supported) {
        where = strstr((const char*)start, ext);
        if (!where) break;
        supported = true;
        supported &= (where == start) || (where[-1] == ' ');
        terminator = where + strlen(ext);
        supported &= (*terminator == '\0') || (*terminator == ' ');
        start = terminator;
    }
    return supported;
}
