/*
 * jack_oscrolloscope
 *
 * Copyright (C) 2006  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <SDL.h>
#include <GL/gl.h>
#include <jack/ringbuffer.h>
#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "video.h"
#include "audio.h"
#include "waves.h"


typedef struct {
    int upper;
    int lower;
    bool clipping;
} waves_line;


static void waves_exit();

static void (*waves_clear_line_all)(int);
static void (*waves_draw_line)(int, int, waves_line*);
static void (*waves_draw_play_head)(int);

static void waves_clear_line_all_gl(int);
static void waves_draw_line_gl(int, int, waves_line*);
static void waves_draw_play_head_gl(int);

static void waves_update_gl_lines(int, int);

static void waves_clear_line_all_sdl(int);
static void waves_draw_line_sdl(int, int, waves_line*);
static void waves_draw_play_head_sdl(int);


int waves_duration = DEFAULT_DURATION;
bool waves_show_clipping = false;

static sample_t *frames = NULL;
static int waves_height;
static int frames_per_line;
static size_t bytes_per_line;
static int draw_pos = 0;

static Uint32 waves_color_sdl,
       waves_color_clipping_sdl,
       waves_color_position_sdl;

static waves_line **waves_lines = NULL;

static const GLfloat waves_color_gl[] = { 0.0f, 1.0f, 0.0f };
static const GLfloat waves_color_clipping_gl[] = { 1.0f, 0.0f, 0.0f };
static const GLfloat waves_color_position_gl[] = { 1.0f, 1.0f, 1.0f };


void waves_init()
{
    if (video_use_gl)
    {
        waves_clear_line_all = waves_clear_line_all_gl;
        waves_draw_line = waves_draw_line_gl;
        waves_draw_play_head = waves_draw_play_head_gl;

        if (!video_use_gl_fbo) {
            waves_lines = calloc(main_nports, sizeof(waves_line*));
            video_set_update_func(waves_update_gl_lines);
        }
    }
    else
    {
        waves_color_sdl = SDL_MapRGB(video_pix_fmt, 0, 255, 0);
        waves_color_clipping_sdl = waves_show_clipping ? SDL_MapRGB(video_pix_fmt, 255, 0, 0) : waves_color_sdl;
        waves_color_position_sdl = SDL_MapRGB(video_pix_fmt, 255, 255, 255);

        waves_clear_line_all = waves_clear_line_all_sdl;
        waves_draw_line = waves_draw_line_sdl;
        waves_draw_play_head = waves_draw_play_head_sdl;
    }

    waves_adjust();
    atexit(waves_exit);
}


static void waves_exit()
{
    if (video_use_gl && !video_use_gl_fbo)
    {
        for (int n = 0; n < main_nports; n++) {
            free(waves_lines[n]);
        }
        free(waves_lines);
    }

    free(frames);
}


void waves_adjust()
{
    waves_height = video_height / main_nports;
    frames_per_line = (audio_samplerate * waves_duration) / video_width;
    bytes_per_line = frames_per_line * sizeof(sample_t);
    draw_pos = 0;

    frames = realloc(frames, frames_per_line * sizeof(sample_t));

    if (video_use_gl && !video_use_gl_fbo)
    {
        for (int n = 0; n < main_nports; n++) {
            free(waves_lines[n]);
            waves_lines[n] = calloc(video_width, sizeof(waves_line));
        }
    }
}


static inline void waves_analyze_frames(waves_line *line)
{
    sample_t maxi = frames[0];
    sample_t mini = frames[0];
    line->clipping = false;
    // find maximum and minimum sample value
    for (int i = 1; i < frames_per_line; i++) {
        if (frames[i] > maxi) maxi = frames[i];
        if (frames[i] < mini) mini = frames[i];
        if (frames[i] >= 1.0 || frames[i] <= -1.0) line->clipping = true;
    }
    line->upper = ((int)(waves_height * (1.0f - maxi))) / 2;
    line->lower = ((int)(waves_height * (1.0f - mini))) / 2;

    // make sure we always draw at least one pixel
    if (line->upper == line->lower) {
        line->upper = waves_height / 2 - 1;
        line->lower = waves_height / 2;
    }
}


static void waves_clear_line_all_gl(int pos)
{
    if (video_use_gl_fbo) {
        glColor3f(0.0f, 0.0f, 0.0f);

        glBegin(GL_LINES);
            glVertex2i(pos, 0);
            glVertex2i(pos, video_height);
        glEnd();
    }
}


static void waves_draw_line_gl(int pos, int ntrack, waves_line *line)
{
    if (video_use_gl_fbo) {
        glColor3fv(waves_show_clipping && line->clipping ? waves_color_clipping_gl : waves_color_gl);

        glBegin(GL_LINES);
            glVertex2i(pos, ntrack * waves_height + line->upper);
            glVertex2i(pos, ntrack * waves_height + line->lower);
        glEnd();
    } else {
        waves_lines[ntrack][draw_pos] = *line;
    }
}


static void waves_draw_play_head_gl(int pos)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glBegin(GL_LINES);
    glColor3fv(waves_color_position_gl);
    glVertex2i(pos, 0);
    glVertex2i(pos, video_height);
    glVertex2i(pos + 1, 0);
    glVertex2i(pos + 1, video_height);
    for (int x = 2; x < 20; x++) {
        glColor4f(0.0f, 0.0f, 0.0f, 0.6f - (0.03f * x));
        glVertex2i((pos + x) % video_width, 0);
        glVertex2i((pos + x) % video_width, video_height);
    }
    glEnd();

    glDisable(GL_BLEND);
}


void waves_update_gl_lines(int pos, int prev_pos)
{
    for (int n = 0; n < main_nports; n++)
    {
        int wave_y = n * waves_height;

        for (int x = 0; x < video_width; x++)
        {
            if (waves_lines[n][x].lower == 0) break;

            if (waves_show_clipping && waves_lines[n][x].clipping) {
                glColor3fv(waves_color_clipping_gl);
            } else {
                glColor3fv(waves_color_gl);
            }

            int xp = video_scrolling ? ((video_width - pos + x) % video_width) : x;

            if (waves_lines[n][x].upper < waves_lines[n][x].lower - 1) {
                glBegin(GL_LINES);
                glVertex2i(xp, wave_y + waves_lines[n][x].upper);
                glVertex2i(xp, wave_y + waves_lines[n][x].lower);
                glEnd();
            } else {
                glBegin(GL_POINTS);
                glVertex2i(xp, wave_y + waves_lines[n][x].lower);
                glEnd();
            }
        }
    }
}


static void waves_clear_line_all_sdl(int pos)
{
    SDL_Rect r = { pos, 0, 1, video_height };
    SDL_FillRect(video_draw_surface, &r, 0);
}


static void waves_draw_line_sdl(int pos, int ntrack, waves_line *line)
{
    SDL_Rect r = { pos, ntrack * waves_height + line->upper, 1, line->lower - line->upper };
    SDL_FillRect(video_draw_surface, &r, (line->clipping ? waves_color_clipping_sdl : waves_color_sdl));
}


static void waves_draw_play_head_sdl(int pos)
{
    SDL_Rect r_pos = { pos, 0, 2, video_height };
    SDL_FillRect(video_draw_surface, &r_pos, waves_color_position_sdl);
    SDL_Rect r_pos_black = { (pos + 2) % video_width, 0, 2, video_height };
    SDL_FillRect(video_draw_surface, &r_pos_black, 0);
}


void waves_draw()
{
    int prev_pos = draw_pos;

    if (video_use_gl && !video_use_gl_fbo) {
        glClear(GL_COLOR_BUFFER_BIT);
    }

    video_set_draw_target(DRAW_TO_BUFFER);

    while ( ({ bool ready = true;
               for (int n = 0; n < main_nports; n++) {
                   if (jack_ringbuffer_read_space(audio_buffers[n]) < bytes_per_line) { ready = false; }
               }
               ready; }) )
    {
        waves_clear_line_all(draw_pos);

        for (int n = 0; n < main_nports; n++)
        {
            waves_line line;
            jack_ringbuffer_read(audio_buffers[n], (void*)frames, bytes_per_line);
            waves_analyze_frames(&line);
            waves_draw_line(draw_pos, n, &line);
        }

        draw_pos = (draw_pos + 1) % video_width;
    }

    video_set_draw_target(DRAW_TO_SCREEN);

    video_update(draw_pos, prev_pos);

    if (!video_scrolling) {
        // play head is not drawn into framebuffer!
        waves_draw_play_head(draw_pos);
    }
}
