/*
 * jack_oscrolloscope
 *
 * Copyright (C) 2006  Dominic Sacré  <dominic.sacre@gmx.de>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <SDL.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdlib.h>

#include "main.h"
#include "video.h"


int video_ticks_per_frame = 1000 / DEFAULT_FPS;
static int ticks = 0;

SDL_Surface *video_screen = NULL;

bool video_use_gl = false;
int video_width = DEFAULT_WIDTH,
    video_height = 0;


void video_init()
{
    if (video_use_gl) {
        if (video_ticks_per_frame == 0) {
            // attempt to enable vsync, which makes scrolling more smooth.
            // probably has no effect on anything but nVidia cards.
            setenv("__GL_SYNC_TO_VBLANK", "1", 0);
        }
        SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
        SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    }

    video_set_mode(video_width, video_height);
}


void video_set_mode(int w, int h)
{
    if ((video_screen = SDL_SetVideoMode(w, h, VIDEO_BPP,
                                         (video_use_gl ? VIDEO_FLAGS_GL : VIDEO_FLAGS_SDL))) == NULL) {
        fprintf(stderr, "can't set video mode: %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }

    if (video_use_gl) {
        glViewport(0, 0, w, h);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, w, h, 0, 0, 1);

        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    video_width = w;
    video_height = h;
}


void video_resize(int w, int h)
{
    video_set_mode(w, h);

    video_width = w;
    video_height = h;
}


void video_flip()
{
    while (SDL_GetTicks() < ticks + video_ticks_per_frame) {
        SDL_Delay(1);
    }
    ticks = SDL_GetTicks();

    if (video_use_gl) {
        SDL_GL_SwapBuffers();
    } else {
        SDL_Flip(video_screen);
    }
}
